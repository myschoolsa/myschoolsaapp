define( function ( require ) {

	"use strict";

	return {
		app_slug : 'myschoolsa',
		wp_ws_url : 'http://www.myschoolsa.com/wp-appkit-api/myschoolsa',
		wp_url : 'http://www.myschoolsa.com',
		theme : 'q-android',
		version : '0.2',
		app_title : 'MySchoolSA',
		app_platform : 'android',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : 'gab1tsm3nik3ocw3opfnfahlfwujzhlmxzbquq27sizfmx0pqmwlscray5k72mla',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
